/*
Question 2: DSA Given an array of integers nums and an integer target, 
return the indices of the two numbers such that they add up to target. 
You may assume that each input would have exactly one solution, 
and you may not use the same element twice. You can return the answer in any order.

For example, given:

const nums = [2, 7, 11, 15];

const target = 9;

The function should return [0, 1] because nums[0] + nums[1] = 2 + 7 = 9.

Requirements:
Implement the solution in JavaScript.
The solution should have a time complexity better than O(n^2).
Include proper error handling for edge cases.
*/

function twoSum(nums, target) {
    if (nums.length < 2) {
        throw new Error("Array must contain at least two elements.");
    }

    const numMap = new Map();

    for (let i = 0; i < nums.length; i++) {
        const complement = target - nums[i];

        if (numMap.has(complement)) {
            return [numMap.get(complement), i];
        }

        numMap.set(nums[i], i);
    }

    throw new Error("No two numbers add up to the target.");
}

console.log(twoSum([2, 7, 11, 15], 9)); 

// Output: [0, 1]

// explanation
/*
    Create a Map: numMap stores numbers as keys and their indices as values.
Loop through the array:
    For each number, calculate the complement:
    complement = target - current number
    Check if the complement exists in numMap:
        If it does, return the indices: [numMap.get(complement), current index]
    Add the current number and its index to numMap:
        numMap.set(current number, current index)

    If no pair is found after the loop, throw an error.
*/